<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    footer{
      position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color:#4a98f7;
  
   text-align: center;
    }
    .text{
      color:white;
    }
  </style>
</head>
<body>
<div class="container">
  <footer class="py-1 ">
 
    <p class="text-center text">&copy; 2022 Company, Inc</p>
  </footer>
</div>
</body>
</html>
